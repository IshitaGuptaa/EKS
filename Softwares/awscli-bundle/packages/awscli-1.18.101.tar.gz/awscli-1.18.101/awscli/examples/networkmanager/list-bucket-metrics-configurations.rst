**To retrieve a list of metrics configurations for a bucket**

The following ``list-bucket-metrics-configurations`` example retrieves a list of metrics configurations for the specified bucket. ::

    aws s3api list-bucket-metrics-configurations \
        --bucket my-bucket

Output::

    {
        "IsTruncated": false,
        "MetricsConfigurationList": [
            {
                "Filter": {
                    "Prefix": "logs"
                },
                "Id": "123"
            },
            {
                "Filter": {
                    "Prefix": "tmp"
                },
                "Id": "234"
            }
        ]
    }
